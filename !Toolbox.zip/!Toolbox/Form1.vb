﻿Imports System.Xml.Linq
Imports System.IO

Public Class Form1
    Private blnAttribute
    Private blnNode


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim OpenFileDialog1 As New OpenFileDialog
        OpenFileDialog1.InitialDirectory = "%USERPROFILE%\desktop"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Multiselect = False
        OpenFileDialog1.Filter = "XML|*.xml"
        If OpenFileDialog1.ShowDialog Then
            Dim sName As String = OpenFileDialog1.SafeFileName
            txtPath.Text = OpenFileDialog1.FileName
        End If
    End Sub


    Private Sub btnMakeList_Click(sender As Object, e As EventArgs) Handles btnMakeList.Click
        'Dim strTargetText As String
        Dim xdoc As XDocument
        Dim xElm As XElement
        Dim lstValues = New List(Of String)

        'Dim txtOutputPath As String
        'Dim fileName As String
        'fileName = System.IO.Path.GetFileName(txtPath.Text)
        'txtOutputPath = Microsoft.VisualBasic.Left(txtPath.Text, txtPath.Text.Length - fileName.Length)


        'strTargetText = txtNode.Text
        xdoc = XDocument.Load(txtpath.text)
        xElm = xdoc.Root

        Dim childList As IEnumerable(Of XElement) = From el In xdoc.Descendants(txtNode.Text)
        For Each node As XElement In childList

            lstValues.Add(node.Attribute(txtAttribute.Text))
        Next

        writeListToTxt(lstValues)

    End Sub

    Private Sub writeListToTxt(ByVal listOfValues As List(Of String))
        Dim strOutputPath As String
        Dim fileName As String
        Dim strOutputFile As String

        If listOfValues.Count < 1 Then
            MsgBox("list is empty.  You screwed something up, dog.")
            Exit Sub
        End If

        fileName = System.IO.Path.GetFileName(txtPath.Text)
        strOutputPath = Microsoft.VisualBasic.Left(txtPath.Text, txtPath.Text.Length - fileName.Length)

        strOutputFile = strOutputPath & txtOutputFileName.Text & ".txt"
        For Each Val As String In listOfValues
            File.AppendAllText(strOutputFile, Val & vbCrLf)

        Next
        ' File.AppendAllText(strOutputFile, listOfValues)

        File.AppendAllLines(strOutputFile, listOfValues)
        MsgBox("Done")
        System.Diagnostics.Process.Start(strOutputFile)


    End Sub

    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        Dim FolderBrowserDialog1 As New FolderBrowserDialog

        Dim sPath As String

        If FolderBrowserDialog1.ShowDialog Then
            sPath = FolderBrowserDialog1.SelectedPath
            txtDirectory.Text = sPath
        End If

        
    End Sub

    Private Sub btnRename_Click(sender As Object, e As EventArgs) Handles btnRename.Click

        Dim diTargetDir As New DirectoryInfo(txtDirectory.Text)
        Dim count As Integer

        'diTargetDir = New DirectoryInfo(txtDirectory.Text)
        For Each file As FileInfo In diTargetDir.GetFiles
            If file.Extension = txtOldExtension.Text Then
                file.MoveTo(Replace(file.FullName, txtOldExtension.Text, LCase(txtNewExtension.Text)))
                count += 1
            End If
        Next


        MsgBox(count & " files renamed!" & vbCrLf & "HAVE A NICE DAY!!")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim strInput As String
        Dim strDelimiter As String
        strInput = txtInput.Text
        strDelimiter = txtDelimiter.Text

        txtOutput.Text = Replace(strInput, strDelimiter, "" & vbCrLf)


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim srcPath, destPath As String
        Dim fi As FileInfo

        srcPath = txtSourceDir.text
        destPath = txtOutputDir.Text

        ProcessDirectory(srcPath)

    End Sub


    Public Sub ProcessDirectory(ByVal targetDirectory As String)

        Dim retval As Date = Date.MinValue
        Dim subdirectoryEntries As String() = System.IO.Directory.GetDirectories(targetDirectory)
        Dim subdirectory As String

        For Each subdirectory In subdirectoryEntries
            ProcessDirectory(subdirectory)
        Next subdirectory

        Dim FileEntries As String() = System.IO.Directory.GetFiles(targetDirectory)
        Dim FileFullName As String

        Try

            For Each FileFullName In FileEntries
                If Microsoft.VisualBasic.Right(FileFullName, 4).ToUpper() = ".TIF" Then
                    My.Computer.FileSystem.CopyFile(FileFullName, txtOutputDir.Text & "\" & DateTime.Now.AddMilliseconds(1.5).ToString() & ".TIF", True)
                End If
            Next FileFullName

        Catch ex As Exception
            MsgBox(ex.Message & vbLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cboExtensions.Items.Add(".TIF")
        cboExtensions.Items.Add(".XML")
    End Sub

    Private Sub btnWhosLoggedOn_Click(sender As Object, e As EventArgs) Handles btnWhosLoggedOn.Click

        Dim oProcess As New Process()
        Dim oStartInfo As New ProcessStartInfo("PsLoggedon.exe", "  " & txtPCName.Text)
        Try
            Label17.Text = ""

            oStartInfo.UseShellExecute = False
            oStartInfo.RedirectStandardOutput = True
            oProcess.StartInfo = oStartInfo
            oProcess.Start()

            Dim sOutput As String
            Using oStreamReader As System.IO.StreamReader = oProcess.StandardOutput
                sOutput = oStreamReader.ReadToEnd()
            End Using
            Label15.Text = sOutput
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & ex.StackTrace)
        End Try

    End Sub

    Private Sub btnFileAvailable_Click(sender As Object, e As EventArgs) Handles btnFileAvailable.Click

        Dim path As String = txtFileAvailablePath.Text
        path = path.Replace("""", "")


        Dim bReturn As Boolean = True
        Try
            Using FileStream As System.IO.FileStream = New System.IO.FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)
                Label22.Text = "FILE IS AVAILABLE"
            End Using
        Catch ex As Exception
            Label22.Text = "FILE IS NOT AVAILABLE"
        End Try





    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim service As New ER_GetPrintServerPrinters.ER_GetPrintServerPrintersClient
        Dim dt As New Dictionary(Of String, String)
        Dim str As String

        dt = service.GetPrinters()
        For Each kvp As KeyValuePair(Of String, String) In dt
            MsgBox("key: " & kvp.Key & "  Value: " & kvp.Value)


        Next




    End Sub

    Private Sub TabPage7_Click(sender As Object, e As EventArgs) Handles TabPage7.Click

        'Dim strTargetText As String
        Dim xdoc As XDocument
        Dim xElm As XElement
        Dim lstValues = New List(Of String)

        Try
            xdoc = XDocument.Load("C:\Users\thompne\Downloads\Lookup\Lookup.xml")
            xElm = xdoc.Root

            Dim childList As IEnumerable(Of XElement) = From el In xdoc.Descendants("ChoiceDataSourceEntity")
            For Each node As XElement In childList

                lstValues.Add(node.Attribute(txtAttribute.Text))
            Next

            writeListToTxt(lstValues)
        Catch ex As Exception

        End Try

    End Sub

    'Private Sub writeListToTxt(ByVal listOfValues As List(Of String))
    '    Dim strOutputPath As String
    '    Dim fileName As String
    '    Dim strOutputFile As String

    '    If listOfValues.Count < 1 Then
    '        MsgBox("list is empty.  You screwed something up, dog.")
    '        Exit Sub
    '    End If

    '    fileName = System.IO.Path.GetFileName(txtPath.Text)
    '    strOutputPath = Microsoft.VisualBasic.Left(txtPath.Text, txtPath.Text.Length - fileName.Length)

    '    strOutputFile = strOutputPath & txtOutputFileName.Text & ".txt"
    '    For Each Val As String In listOfValues
    '        File.AppendAllText(strOutputFile, Val & vbCrLf)

    '    Next
    '    ' File.AppendAllText(strOutputFile, listOfValues)

    '    File.AppendAllLines(strOutputFile, listOfValues)
    '    MsgBox("Done")
    '    System.Diagnostics.Process.Start(strOutputFile)



End Class
