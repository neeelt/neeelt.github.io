﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtPath = New System.Windows.Forms.TextBox()
        Me.txtAttribute = New System.Windows.Forms.TextBox()
        Me.btnMakeList = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtNode = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtOutputFileName = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.StringBuster = New System.Windows.Forms.TabControl()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtPCName = New System.Windows.Forms.TextBox()
        Me.btnWhosLoggedOn = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtNewExtension = New System.Windows.Forms.TextBox()
        Me.btnBrowse = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Directory = New System.Windows.Forms.Label()
        Me.btnRename = New System.Windows.Forms.Button()
        Me.txtOldExtension = New System.Windows.Forms.TextBox()
        Me.txtDirectory = New System.Windows.Forms.TextBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtInput = New System.Windows.Forms.RichTextBox()
        Me.txtOutput = New System.Windows.Forms.RichTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtDelimiter = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtOutputDir = New System.Windows.Forms.TextBox()
        Me.cboExtensions = New System.Windows.Forms.ComboBox()
        Me.txtSourceDir = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtFileAvailablePath = New System.Windows.Forms.TextBox()
        Me.btnFileAvailable = New System.Windows.Forms.Button()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.StringBuster.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.SuspendLayout()
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Modern No. 20", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(344, 138)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(54, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Browse"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtPath
        '
        Me.txtPath.Location = New System.Drawing.Point(33, 141)
        Me.txtPath.Name = "txtPath"
        Me.txtPath.Size = New System.Drawing.Size(298, 20)
        Me.txtPath.TabIndex = 0
        '
        'txtAttribute
        '
        Me.txtAttribute.Location = New System.Drawing.Point(126, 254)
        Me.txtAttribute.Name = "txtAttribute"
        Me.txtAttribute.Size = New System.Drawing.Size(176, 20)
        Me.txtAttribute.TabIndex = 4
        '
        'btnMakeList
        '
        Me.btnMakeList.Font = New System.Drawing.Font("Modern No. 20", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMakeList.Location = New System.Drawing.Point(186, 313)
        Me.btnMakeList.Name = "btnMakeList"
        Me.btnMakeList.Size = New System.Drawing.Size(75, 23)
        Me.btnMakeList.TabIndex = 5
        Me.btnMakeList.Text = "Do It!!!"
        Me.btnMakeList.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Modern No. 20", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(52, 259)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 15)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Attribute:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Modern No. 20", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(36, 233)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 15)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Node:"
        '
        'txtNode
        '
        Me.txtNode.Location = New System.Drawing.Point(83, 228)
        Me.txtNode.Name = "txtNode"
        Me.txtNode.Size = New System.Drawing.Size(176, 20)
        Me.txtNode.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Modern No. 20", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(40, 164)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(122, 15)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Output File Name:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Modern No. 20", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(40, 125)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(130, 15)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Path To Input File:"
        '
        'txtOutputFileName
        '
        Me.txtOutputFileName.Location = New System.Drawing.Point(33, 180)
        Me.txtOutputFileName.Name = "txtOutputFileName"
        Me.txtOutputFileName.Size = New System.Drawing.Size(168, 20)
        Me.txtOutputFileName.TabIndex = 2
        Me.txtOutputFileName.Text = "BatchClasses"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Modern No. 20", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(204, 182)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 15)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "(.txt)"
        '
        'StringBuster
        '
        Me.StringBuster.Controls.Add(Me.TabPage5)
        Me.StringBuster.Controls.Add(Me.TabPage2)
        Me.StringBuster.Controls.Add(Me.TabPage1)
        Me.StringBuster.Controls.Add(Me.TabPage3)
        Me.StringBuster.Controls.Add(Me.TabPage4)
        Me.StringBuster.Controls.Add(Me.TabPage6)
        Me.StringBuster.Controls.Add(Me.TabPage7)
        Me.StringBuster.Location = New System.Drawing.Point(23, 12)
        Me.StringBuster.Name = "StringBuster"
        Me.StringBuster.SelectedIndex = 0
        Me.StringBuster.Size = New System.Drawing.Size(523, 378)
        Me.StringBuster.TabIndex = 13
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.Label21)
        Me.TabPage5.Controls.Add(Me.Label17)
        Me.TabPage5.Controls.Add(Me.Label16)
        Me.TabPage5.Controls.Add(Me.Label15)
        Me.TabPage5.Controls.Add(Me.txtPCName)
        Me.TabPage5.Controls.Add(Me.btnWhosLoggedOn)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(515, 352)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Who'sLoggedOn"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(16, 16)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(387, 51)
        Me.Label21.TabIndex = 5
        Me.Label21.Text = "This utility gets the user name of logged on users on a remote PC.  Used for find" &
    "ing out who's on a Kofax PC."
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(3, 309)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(476, 43)
        Me.Label17.TabIndex = 4
        Me.Label17.Text = "As an alternative, open a command window and run: PSLoggedon -L ""\\[pcname]""  Not" &
    "e:  This requres PSLoggedon.exe from SysInternals"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(16, 82)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(63, 13)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "PC Name:"
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(16, 123)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(476, 228)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Who indeed..."
        '
        'txtPCName
        '
        Me.txtPCName.Location = New System.Drawing.Point(19, 98)
        Me.txtPCName.Name = "txtPCName"
        Me.txtPCName.Size = New System.Drawing.Size(230, 20)
        Me.txtPCName.TabIndex = 1
        Me.txtPCName.Text = "\\"
        '
        'btnWhosLoggedOn
        '
        Me.btnWhosLoggedOn.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWhosLoggedOn.Location = New System.Drawing.Point(255, 96)
        Me.btnWhosLoggedOn.Name = "btnWhosLoggedOn"
        Me.btnWhosLoggedOn.Size = New System.Drawing.Size(127, 22)
        Me.btnWhosLoggedOn.TabIndex = 0
        Me.btnWhosLoggedOn.Text = "Knock Knock...."
        Me.btnWhosLoggedOn.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label18)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.txtNewExtension)
        Me.TabPage2.Controls.Add(Me.btnBrowse)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.Directory)
        Me.TabPage2.Controls.Add(Me.btnRename)
        Me.TabPage2.Controls.Add(Me.txtOldExtension)
        Me.TabPage2.Controls.Add(Me.txtDirectory)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(515, 352)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "FileRenamer"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Modern No. 20", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(32, 35)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(454, 57)
        Me.Label18.TabIndex = 8
        Me.Label18.Text = "This utility renames all files of a specific type in a target directory to a diff" &
    "erent file extension.  Used to change .xml to .txt in a flash!"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Modern No. 20", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(32, 209)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(96, 15)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "New Extension:"
        '
        'txtNewExtension
        '
        Me.txtNewExtension.Location = New System.Drawing.Point(134, 207)
        Me.txtNewExtension.Name = "txtNewExtension"
        Me.txtNewExtension.Size = New System.Drawing.Size(100, 20)
        Me.txtNewExtension.TabIndex = 3
        '
        'btnBrowse
        '
        Me.btnBrowse.Font = New System.Drawing.Font("Modern No. 20", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBrowse.Location = New System.Drawing.Point(415, 155)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(54, 23)
        Me.btnBrowse.TabIndex = 1
        Me.btnBrowse.Text = "Browse"
        Me.btnBrowse.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Modern No. 20", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(38, 183)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(93, 15)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Old Extension:"
        '
        'Directory
        '
        Me.Directory.AutoSize = True
        Me.Directory.Font = New System.Drawing.Font("Modern No. 20", 8.999999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Directory.Location = New System.Drawing.Point(44, 139)
        Me.Directory.Name = "Directory"
        Me.Directory.Size = New System.Drawing.Size(109, 15)
        Me.Directory.TabIndex = 3
        Me.Directory.Text = "Target Directory:"
        '
        'btnRename
        '
        Me.btnRename.Font = New System.Drawing.Font("Modern No. 20", 8.249999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRename.Location = New System.Drawing.Point(41, 248)
        Me.btnRename.Name = "btnRename"
        Me.btnRename.Size = New System.Drawing.Size(132, 23)
        Me.btnRename.TabIndex = 4
        Me.btnRename.Text = "Rename Files!!"
        Me.btnRename.UseVisualStyleBackColor = True
        '
        'txtOldExtension
        '
        Me.txtOldExtension.Location = New System.Drawing.Point(134, 181)
        Me.txtOldExtension.Name = "txtOldExtension"
        Me.txtOldExtension.Size = New System.Drawing.Size(100, 20)
        Me.txtOldExtension.TabIndex = 2
        '
        'txtDirectory
        '
        Me.txtDirectory.Location = New System.Drawing.Point(35, 155)
        Me.txtDirectory.Name = "txtDirectory"
        Me.txtDirectory.Size = New System.Drawing.Size(374, 20)
        Me.txtDirectory.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label19)
        Me.TabPage1.Controls.Add(Me.btnMakeList)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.txtOutputFileName)
        Me.TabPage1.Controls.Add(Me.txtPath)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.txtAttribute)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.txtNode)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(515, 352)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "ListFromXML"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Modern No. 20", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(30, 17)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(437, 72)
        Me.Label19.TabIndex = 13
        Me.Label19.Text = "This tool is used to build a list of all the values in an XML file that match the" &
    " node / attribute entered.  Used to build a list of batch classes from the XML i" &
    "n a Kofax exported .Cab file."
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Label11)
        Me.TabPage3.Controls.Add(Me.Label10)
        Me.TabPage3.Controls.Add(Me.Label9)
        Me.TabPage3.Controls.Add(Me.txtInput)
        Me.TabPage3.Controls.Add(Me.txtOutput)
        Me.TabPage3.Controls.Add(Me.Label6)
        Me.TabPage3.Controls.Add(Me.txtDelimiter)
        Me.TabPage3.Controls.Add(Me.Button2)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(515, 352)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "StringBuster"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(11, 13)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(320, 31)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Inserts line breaks in a string each time a delimiter is encountered, creating a " &
    "list that can be copied."
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(3, 179)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(47, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Delimiter"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(3, 215)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 33)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Output String"
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(54, 47)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(275, 108)
        Me.txtInput.TabIndex = 7
        Me.txtInput.Text = ""
        '
        'txtOutput
        '
        Me.txtOutput.Location = New System.Drawing.Point(51, 212)
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.Size = New System.Drawing.Size(275, 108)
        Me.txtOutput.TabIndex = 6
        Me.txtOutput.Text = ""
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(11, 47)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 33)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Input String"
        '
        'txtDelimiter
        '
        Me.txtDelimiter.Location = New System.Drawing.Point(51, 176)
        Me.txtDelimiter.Name = "txtDelimiter"
        Me.txtDelimiter.Size = New System.Drawing.Size(108, 20)
        Me.txtDelimiter.TabIndex = 2
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(204, 176)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 0
        Me.Button2.Text = "Split It!!"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Label20)
        Me.TabPage4.Controls.Add(Me.Label14)
        Me.TabPage4.Controls.Add(Me.Label13)
        Me.TabPage4.Controls.Add(Me.Label12)
        Me.TabPage4.Controls.Add(Me.txtOutputDir)
        Me.TabPage4.Controls.Add(Me.cboExtensions)
        Me.TabPage4.Controls.Add(Me.txtSourceDir)
        Me.TabPage4.Controls.Add(Me.Button3)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(515, 352)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "LoopingFileCopy"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Palatino Linotype", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(6, 9)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(332, 79)
        Me.Label20.TabIndex = 7
        Me.Label20.Text = resources.GetString("Label20.Text")
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(14, 175)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(75, 13)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "Output Path"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(14, 128)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(186, 13)
        Me.Label13.TabIndex = 5
        Me.Label13.Text = "Input Path (and sub directories)"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(14, 88)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(86, 13)
        Me.Label12.TabIndex = 4
        Me.Label12.Text = "File Extension"
        '
        'txtOutputDir
        '
        Me.txtOutputDir.Location = New System.Drawing.Point(6, 194)
        Me.txtOutputDir.Name = "txtOutputDir"
        Me.txtOutputDir.Size = New System.Drawing.Size(316, 20)
        Me.txtOutputDir.TabIndex = 3
        '
        'cboExtensions
        '
        Me.cboExtensions.FormattingEnabled = True
        Me.cboExtensions.Location = New System.Drawing.Point(3, 104)
        Me.cboExtensions.Name = "cboExtensions"
        Me.cboExtensions.Size = New System.Drawing.Size(121, 21)
        Me.cboExtensions.TabIndex = 2
        '
        'txtSourceDir
        '
        Me.txtSourceDir.Location = New System.Drawing.Point(6, 152)
        Me.txtSourceDir.Name = "txtSourceDir"
        Me.txtSourceDir.Size = New System.Drawing.Size(316, 20)
        Me.txtSourceDir.TabIndex = 1
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Palatino Linotype", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(6, 242)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 0
        Me.Button3.Text = "POW!!"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.Button4)
        Me.TabPage6.Controls.Add(Me.Label23)
        Me.TabPage6.Controls.Add(Me.Label22)
        Me.TabPage6.Controls.Add(Me.txtFileAvailablePath)
        Me.TabPage6.Controls.Add(Me.btnFileAvailable)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(515, 352)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "FileAvailable"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(247, 61)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "Button4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(61, 120)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(45, 13)
        Me.Label23.TabIndex = 3
        Me.Label23.Text = "FilePath"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(61, 198)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(45, 13)
        Me.Label22.TabIndex = 2
        Me.Label22.Text = "Label22"
        '
        'txtFileAvailablePath
        '
        Me.txtFileAvailablePath.Location = New System.Drawing.Point(64, 136)
        Me.txtFileAvailablePath.Name = "txtFileAvailablePath"
        Me.txtFileAvailablePath.Size = New System.Drawing.Size(271, 20)
        Me.txtFileAvailablePath.TabIndex = 1
        '
        'btnFileAvailable
        '
        Me.btnFileAvailable.Location = New System.Drawing.Point(341, 136)
        Me.btnFileAvailable.Name = "btnFileAvailable"
        Me.btnFileAvailable.Size = New System.Drawing.Size(75, 23)
        Me.btnFileAvailable.TabIndex = 0
        Me.btnFileAvailable.Text = "Check"
        Me.btnFileAvailable.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(515, 352)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "TabPage7"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(573, 419)
        Me.Controls.Add(Me.StringBuster)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "ToolBox"
        Me.StringBuster.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txtPath As System.Windows.Forms.TextBox
    Friend WithEvents txtAttribute As System.Windows.Forms.TextBox
    Friend WithEvents btnMakeList As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtNode As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtOutputFileName As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents StringBuster As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtNewExtension As System.Windows.Forms.TextBox
    Friend WithEvents btnBrowse As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Directory As System.Windows.Forms.Label
    Friend WithEvents btnRename As System.Windows.Forms.Button
    Friend WithEvents txtOldExtension As System.Windows.Forms.TextBox
    Friend WithEvents txtDirectory As System.Windows.Forms.TextBox
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtDelimiter As System.Windows.Forms.TextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents txtOutput As System.Windows.Forms.RichTextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtInput As System.Windows.Forms.RichTextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtOutputDir As System.Windows.Forms.TextBox
    Friend WithEvents cboExtensions As System.Windows.Forms.ComboBox
    Friend WithEvents txtSourceDir As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtPCName As System.Windows.Forms.TextBox
    Friend WithEvents btnWhosLoggedOn As System.Windows.Forms.Button
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtFileAvailablePath As System.Windows.Forms.TextBox
    Friend WithEvents btnFileAvailable As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TabPage7 As TabPage
End Class
